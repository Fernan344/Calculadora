package SubMenuOperacionesBasicas;

public class Raiz {
    public float raices(float numeros){
        float resultado=0;        
        resultado =  (float) Math.sqrt(numeros);            
        return resultado;
    }
}
