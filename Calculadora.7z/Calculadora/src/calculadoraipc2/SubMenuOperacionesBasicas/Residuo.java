
package SubMenuOperacionesBasicas;

public class Residuo {
    public float residuos(float [] numeros){
        float resultado=0;        
        resultado = numeros[0] % numeros[1];            
        return resultado;
    }
}
