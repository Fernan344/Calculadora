package SubMenuOperacionesBasicas;

public class Divicion {
    public float diviciones(float [] numeros){
        float resultado=0;        
        resultado = numeros[0] / numeros[1];            
        return resultado;
    }
}
