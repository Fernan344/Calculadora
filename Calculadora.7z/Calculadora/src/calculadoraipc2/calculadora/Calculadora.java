package calculadora;

import InterfazCalculadora.InterfazPrincipal;

public class Calculadora {

    public static void main(String[] args) {
        InterfazPrincipal calculadora = new InterfazPrincipal();
        calculadora.setVisible(true); 
    }
    
}
